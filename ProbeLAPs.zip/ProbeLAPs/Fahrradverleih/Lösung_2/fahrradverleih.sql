-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2024 at 04:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fahrradverleih`
--

-- --------------------------------------------------------

--
-- Table structure for table `ausleih`
--

CREATE TABLE `ausleih` (
  `id` int(11) NOT NULL,
  `GuthabenkartePin` char(4) NOT NULL,
  `FahrradPin` int(5) NOT NULL,
  `DatumAbfahrt` datetime NOT NULL,
  `DatumAnkunft` datetime NOT NULL,
  `LatAbfahrt` decimal(8,6) NOT NULL,
  `LongAbfahrt` decimal(9,6) NOT NULL,
  `LatAnkunft` decimal(8,6) NOT NULL,
  `LongAnkunft` decimal(9,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ausleih`
--

INSERT INTO `ausleih` (`id`, `GuthabenkartePin`, `FahrradPin`, `DatumAbfahrt`, `DatumAnkunft`, `LatAbfahrt`, `LongAbfahrt`, `LatAnkunft`, `LongAnkunft`) VALUES
(1, '23QF', 89872, '2024-11-18 13:37:10', '2024-11-18 13:57:10', 47.799400, 13.044000, 47.790000, 13.044000),
(2, '23QF', 60000, '2024-11-18 12:57:10', '2024-11-18 13:05:10', 47.799400, 13.044000, 47.790000, 13.044000),
(3, '40CE', 60000, '2024-11-17 10:58:56', '2024-11-17 11:58:56', 47.799400, 13.044000, 47.790000, 13.044000),
(4, '23QF', 7000, '2024-11-18 16:00:38', '2024-11-18 16:18:38', 47.799400, 13.044000, 47.790000, 13.044000),
(5, '50BB', 7000, '2024-11-18 15:10:02', '2024-11-18 16:19:02', 47.799400, 13.044000, 47.790000, 13.044000),
(6, '40CE', 89872, '2024-11-18 16:19:02', '2024-11-18 17:09:02', 47.799400, 13.044000, 47.790000, 13.044000),
(7, '23QF', 89872, '2024-11-18 16:20:53', '2024-11-18 16:22:53', 47.799400, 13.044000, 47.790000, 13.044000),
(8, '23QF', 89872, '2024-11-18 18:22:53', '2024-11-18 18:42:53', 47.799400, 13.044000, 47.790000, 13.044000);

-- --------------------------------------------------------

--
-- Table structure for table `fahrrad`
--

CREATE TABLE `fahrrad` (
  `PIN` int(5) NOT NULL,
  `Typ` int(11) NOT NULL,
  `Hersteller` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fahrrad`
--

INSERT INTO `fahrrad` (`PIN`, `Typ`, `Hersteller`) VALUES
(7000, 1, 1),
(89872, 1, 2),
(60000, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `guthabenkarte`
--

CREATE TABLE `guthabenkarte` (
  `PIN` char(4) NOT NULL,
  `Balance` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guthabenkarte`
--

INSERT INTO `guthabenkarte` (`PIN`, `Balance`) VALUES
('23QF', 20),
('40CE', 66),
('50BB', 7);

-- --------------------------------------------------------

--
-- Table structure for table `hersteller`
--

CREATE TABLE `hersteller` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hersteller`
--

INSERT INTO `hersteller` (`ID`, `Bezeichnung`) VALUES
(1, 'HerstellerA'),
(2, 'HerstellerB');

-- --------------------------------------------------------

--
-- Table structure for table `kosten`
--

CREATE TABLE `kosten` (
  `ID` int(11) NOT NULL,
  `Ausleih` decimal(18,2) NOT NULL,
  `ProMinute` decimal(18,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kosten`
--

INSERT INTO `kosten` (`ID`, `Ausleih`, `ProMinute`) VALUES
(1, 1.00, 0.30);

-- --------------------------------------------------------

--
-- Table structure for table `kunde`
--

CREATE TABLE `kunde` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `GuthabenkartePIN` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kunde`
--

INSERT INTO `kunde` (`ID`, `Name`, `GuthabenkartePIN`) VALUES
(1, 'KundeA', '23QF'),
(2, 'KundeB', '40CE'),
(3, 'KundeC', '50BB');

-- --------------------------------------------------------

--
-- Table structure for table `typ`
--

CREATE TABLE `typ` (
  `ID` int(11) NOT NULL,
  `Bezeichnung` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `typ`
--

INSERT INTO `typ` (`ID`, `Bezeichnung`) VALUES
(1, 'TypA'),
(2, 'TypB');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ausleih`
--
ALTER TABLE `ausleih`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FahrradPin` (`FahrradPin`),
  ADD KEY `GuthabenkartePin` (`GuthabenkartePin`);

--
-- Indexes for table `fahrrad`
--
ALTER TABLE `fahrrad`
  ADD PRIMARY KEY (`PIN`),
  ADD KEY `Typ` (`Typ`,`Hersteller`),
  ADD KEY `fk_hersteller` (`Hersteller`);

--
-- Indexes for table `guthabenkarte`
--
ALTER TABLE `guthabenkarte`
  ADD PRIMARY KEY (`PIN`);

--
-- Indexes for table `hersteller`
--
ALTER TABLE `hersteller`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `kosten`
--
ALTER TABLE `kosten`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `kunde`
--
ALTER TABLE `kunde`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `GuthabenkartePIN` (`GuthabenkartePIN`);

--
-- Indexes for table `typ`
--
ALTER TABLE `typ`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ausleih`
--
ALTER TABLE `ausleih`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `hersteller`
--
ALTER TABLE `hersteller`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `kosten`
--
ALTER TABLE `kosten`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kunde`
--
ALTER TABLE `kunde`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `typ`
--
ALTER TABLE `typ`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ausleih`
--
ALTER TABLE `ausleih`
  ADD CONSTRAINT `ausleih_ibfk_1` FOREIGN KEY (`GuthabenkartePin`) REFERENCES `guthabenkarte` (`PIN`),
  ADD CONSTRAINT `fk_fahrrad` FOREIGN KEY (`FahrradPin`) REFERENCES `fahrrad` (`PIN`);

--
-- Constraints for table `fahrrad`
--
ALTER TABLE `fahrrad`
  ADD CONSTRAINT `fk_hersteller` FOREIGN KEY (`Hersteller`) REFERENCES `hersteller` (`ID`),
  ADD CONSTRAINT `fk_typ` FOREIGN KEY (`Typ`) REFERENCES `typ` (`ID`);

--
-- Constraints for table `kunde`
--
ALTER TABLE `kunde`
  ADD CONSTRAINT `kunde_ibfk_1` FOREIGN KEY (`GuthabenkartePIN`) REFERENCES `guthabenkarte` (`PIN`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
