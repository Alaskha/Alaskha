<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home.php">Home</a>
        </li>
      </ul>
    </div>
  </div>
</nav>