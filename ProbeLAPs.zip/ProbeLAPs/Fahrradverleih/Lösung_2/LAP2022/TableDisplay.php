<?php include "header.php";
include "nav.php";

$dbName = $_GET["db"];
$tableName = $_GET["table"];

$conn = mysqli_connect("localhost", "root", "", "$dbName");

if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
}
$sql = "SHOW COLUMNS FROM $tableName";
$result = $conn->query($sql);
$rowsColumnNames = mysqli_fetch_all($result, MYSQLI_NUM);

$sql = "SELECT * FROM $tableName";
$result = $conn->query($sql);
$rowsEntries = mysqli_fetch_all($result, MYSQLI_NUM);
?>
<html>
<body>
    <form method="POST">
      <div class="form-group">
<table class="table">
<thead>
    <tr>
        <?php for ($x = 0; $x < sizeof($rowsColumnNames); $x++) {
            echo "<th>" . $rowsColumnNames[$x][0] . "</th>";
        } ?>
    </tr>
</thead>
<tbody>
<?php
for ($x = 0; $x < sizeof($rowsEntries); $x++) {
    echo "<tr>";
    for ($j = 0; $j < sizeof($rowsColumnNames); $j++) {
        echo "<td>" . $rowsEntries[$x][$j] . "</td>";
    }
    echo "</tr>";
}
echo "<tr>";

for ($j = 0; $j < sizeof($rowsColumnNames); $j++) {
    echo "<td><input class='form-control' value=''></td>";
}
echo "</tr>";
?>
</tbody>
</table>

<button type='submit' class='btn btn-primary'>Submit</button>
</body>

</html>

