
<?php
$conn = mysqli_connect("localhost", "root", "", "wandertaxi");

if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
}
$sql = "SHOW DATABASES";
$result = $conn->query($sql);
$rowsDBnames = mysqli_fetch_all($result, MYSQLI_NUM);

$dbAndTables = [];

foreach ($rowsDBnames as $db) {
    $sql = "SHOW TABLES FROM " . $db[0];
    $result = $conn->query($sql);
    $rowsTableNames = mysqli_fetch_all($result, MYSQLI_NUM);

    array_push($dbAndTables, [$db[0], $rowsTableNames]);
}

mysqli_close($conn);


?>
