
<?php
$currentDB = $_POST["currentDB"];

$conn = mysqli_connect("localhost", "root", "", "$currentDB");

if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error;
} else {
    $sql = "SHOW TABLES FROM $currentDB";
    $result = $conn->query($sql);
    $rowsTableNames = mysqli_fetch_all($result, MYSQLI_NUM);

    mysqli_close($conn);

    $outputHTML = ".
<select name='tables' id='tables' onchange='setOutputText()'>";

    for ($x = 0; $x < sizeof($rowsTableNames); $x++) {
        $outputHTML .=
            "<option value=" .
            $rowsTableNames[$x][0] .
            ">" .
            $rowsTableNames[$x][0] .
            "</option>";
    }
    $outputHTML .= "
</select>
</fieldset>";

    echo $outputHTML;
}

?>
