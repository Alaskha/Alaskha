<?php include "header.php";
include "nav.php";
include "data.php";
?>
<html>
  <script>
function showTables() {
    /* var divStations = document.getElementById("dom-target-stations");
     var divDays = document.getElementById("dom-target-days");
     var stationsData = JSON.parse(divStations.textContent);
     var daysData = JSON.parse(divDays.textContent);*/

    var currentDB = $('#datenbanken option:selected').val();
if(currentDB != undefined && currentDB != ""){
    $.ajax({
        type: "POST",  //type of method
        url: "/LAP2022/getTableDropdown.php",  //your page
        data: { currentDB: currentDB },// passing the values
        success: function (res) {
            if (res) {
                $("#tableDropdown").html(res);
            }
        }
    });
}
    return false;
}

function setOutputText() {
    var currentDB = $('#datenbanken option:selected').val();
    var currentTable = $('#tables option:selected').val();
    
if(currentDB != undefined && currentDB != "" && currentTable != undefined && currentTable != ""){

    window.location.replace("/LAP2022/TableDisplay.php?db="+currentDB+"&table="+currentTable);
}
    return false;
}

  </script>
  <body>
    <form>
      <div class="form-group">
        <fieldset>
          <label>Datenbanken.Tabellen:</label><br>
          <select name="datenbanken" id="datenbanken" onchange="showTables()">
          <option ></option > <!-- Sodass der Nutzer gezwungen ist, eine DB auszuwählen, ehe erwartet wird, die Tabellen sehen zu können-->
<?php for ($x = 0; $x < sizeof($rowsDBnames); $x++) {
    echo "<option value=" .
        $rowsDBnames[$x][0] .
        ">" .
        $rowsDBnames[$x][0] .
        "</option>";
} ?> 
          </select>
        <label name="tableDropdown" id="tableDropdown"></label>
        </fieldset>

        
      </div>
     
    </form>
    
    <label name="textOutput" id="textOutput"></label>

</body>

</html>