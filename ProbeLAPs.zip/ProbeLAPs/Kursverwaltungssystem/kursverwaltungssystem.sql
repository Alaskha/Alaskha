-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2024 at 05:46 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kursverwaltungssystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `dozenten`
--

CREATE TABLE `dozenten` (
  `idDozenten` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `fachgebiet` varchar(45) DEFAULT NULL,
  `qualifikationen` varchar(45) DEFAULT NULL,
  `passwort` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dozenten`
--

INSERT INTO `dozenten` (`idDozenten`, `name`, `email`, `fachgebiet`, `qualifikationen`, `passwort`) VALUES
(1, 'DozentA', 'DozentA@mail.com', 'FachgebietA', 'QualifikationA', ''),
(2, 'DozentA', 'DozentA@mail.com', 'FachgebietA', 'QualifikationA', '$2y$10$m3kcSGEvQ3bYxj665xrwhurahQdxdlslZ7nF6Z'),
(9, 'DozentA', 'DozentA@mail.com', 'FachgebietA', 'QualifikationA', '$2y$10$QmYkeySWQ5L6IOfrMzOlg.CBPWJdNoz/uEPbzR');

-- --------------------------------------------------------

--
-- Table structure for table `kurs`
--

CREATE TABLE `kurs` (
  `idKurs` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `Dozenten_idDozenten` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kurs`
--

INSERT INTO `kurs` (`idKurs`, `name`, `Dozenten_idDozenten`) VALUES
(1, 'KursA', 1),
(2, 'KursB', 2);

-- --------------------------------------------------------

--
-- Table structure for table `teilnehmer`
--

CREATE TABLE `teilnehmer` (
  `idTeilnehmer` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `passwort` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teilnehmer`
--

INSERT INTO `teilnehmer` (`idTeilnehmer`, `name`, `email`, `passwort`) VALUES
(1, 'TeilnehmerA', 'TeilnehmerAT@com.com', '0'),
(2, 'TeilnehmerB', 'TeilnehmerB@com.com', '0');

-- --------------------------------------------------------

--
-- Table structure for table `teilnehmer_has_kurs`
--

CREATE TABLE `teilnehmer_has_kurs` (
  `Teilnehmer_idTeilnehmer` int(11) NOT NULL,
  `Kurs_idKurs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teilnehmer_has_kurs`
--

INSERT INTO `teilnehmer_has_kurs` (`Teilnehmer_idTeilnehmer`, `Kurs_idKurs`) VALUES
(1, 2),
(2, 1),
(2, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dozenten`
--
ALTER TABLE `dozenten`
  ADD PRIMARY KEY (`idDozenten`);

--
-- Indexes for table `kurs`
--
ALTER TABLE `kurs`
  ADD PRIMARY KEY (`idKurs`),
  ADD KEY `fk_Kurs_Dozenten1` (`Dozenten_idDozenten`);

--
-- Indexes for table `teilnehmer`
--
ALTER TABLE `teilnehmer`
  ADD PRIMARY KEY (`idTeilnehmer`);

--
-- Indexes for table `teilnehmer_has_kurs`
--
ALTER TABLE `teilnehmer_has_kurs`
  ADD KEY `fk_Teilnehmer_has_Kurs_Teilnehmer1` (`Teilnehmer_idTeilnehmer`),
  ADD KEY `fk_Teilnehmer_has_Kurs_Kurs1` (`Kurs_idKurs`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dozenten`
--
ALTER TABLE `dozenten`
  MODIFY `idDozenten` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `kurs`
--
ALTER TABLE `kurs`
  MODIFY `idKurs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `teilnehmer`
--
ALTER TABLE `teilnehmer`
  MODIFY `idTeilnehmer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kurs`
--
ALTER TABLE `kurs`
  ADD CONSTRAINT `fk_Kurs_Dozenten1` FOREIGN KEY (`Dozenten_idDozenten`) REFERENCES `dozenten` (`idDozenten`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `teilnehmer_has_kurs`
--
ALTER TABLE `teilnehmer_has_kurs`
  ADD CONSTRAINT `fk_Teilnehmer_has_Kurs_Kurs1` FOREIGN KEY (`Kurs_idKurs`) REFERENCES `kurs` (`idKurs`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Teilnehmer_has_Kurs_Teilnehmer1` FOREIGN KEY (`Teilnehmer_idTeilnehmer`) REFERENCES `teilnehmer` (`idTeilnehmer`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
