<?php include('data.php');

$teilnehmerID = $_POST['teilnehmerID'];
$kursID = $_POST['kursID'];
$isAnmeldung = $_POST['isAnmeldung'];

$conn = mysqli_connect('localhost', 'root', '', 'Kursverwaltungssystem');

if ($conn -> connect_error) {
    echo "Connection failed: ".$conn -> connect_error;
}

$sql = "";
if ($isAnmeldung == "true") {
    $sql = getInsertTeilnehmerKurs($teilnehmerID, $kursID);
} else {
    $sql = getDeleteTeilnehmerKurs($teilnehmerID, $kursID);
}

$outputHTML = "";
if ($conn -> query($sql)) {
    $sql = "SELECT teilnehmer.name, kurs.name FROM teilnehmer_has_kurs 
INNER JOIN teilnehmer ON teilnehmer_has_kurs.Teilnehmer_idTeilnehmer = teilnehmer.idTeilnehmer 
INNER JOIN kurs ON teilnehmer_has_kurs.Kurs_idKurs = kurs.idKurs
WHERE teilnehmer_has_kurs.Teilnehmer_idTeilnehmer = $teilnehmerID; ";
    $result = $conn -> query($sql);
    $rowsTeilnehmerKurse = mysqli_fetch_all($result, MYSQLI_NUM);
    if (sizeof($rowsTeilnehmerKurse) > 0) {
        $outputHTML = getOutput($teilnehmerID, $rowsTeilnehmerKurse);
    } else {
        $outputHTML = "Dieser Teilnehmer ist bei keinen Kursen angemeldet.";
    }


} else {
    $outputHTML = "Error: ".$sql. "<br>".$conn -> error;
}

mysqli_close($conn);

echo json_encode($outputHTML);

function getDeleteTeilnehmerKurs($teilnehmer, $kurs) {
    return "
      DELETE FROM`teilnehmer_has_kurs`
      WHERE teilnehmer_has_kurs.Teilnehmer_idTeilnehmer = $teilnehmer AND teilnehmer_has_kurs.Kurs_idKurs = $kurs; ";
}

function getInsertTeilnehmerKurs($teilnehmer, $kurs) {
    return "
      INSERT INTO`teilnehmer_has_kurs`(`Teilnehmer_idTeilnehmer`, `Kurs_idKurs`) 
       SELECT $teilnehmer, $kurs
       FROM DUAL
      WHERE NOT EXISTS
        (SELECT teilnehmer_has_kurs.Teilnehmer_idTeilnehmer, teilnehmer_has_kurs.Kurs_idKurs FROM teilnehmer_has_kurs 
      WHERE teilnehmer_has_kurs.Teilnehmer_idTeilnehmer = $teilnehmer AND teilnehmer_has_kurs.Kurs_idKurs = $kurs LIMIT 1); ";
}

function getOutput($teilnehmer, $rows) {
    $output = "Erfolgreich angemeldet. <br>";
    $output.= "<table class='table'>
        <thead>
        <tr>
            <th scope='col'>
                <h4>".  $rows[0][0] ."</h4>
            </th>
            <th scope='col'>
                <h4>Kurse</h4>
            </th>
        </tr>
    </thead >
        <tbody>";
            for ($x = 0; $x < sizeof($rows); $x++) {
                $output.= "<tr>";
            $output .= "<td> </td>";
            $output .= "<td>" . $rows[$x][1] . "</td>";
    }
            $output .= "</tbody></table > ";
    return $output;
}
?>