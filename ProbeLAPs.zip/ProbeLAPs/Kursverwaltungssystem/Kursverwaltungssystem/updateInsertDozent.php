<?php include('data.php');

$conn = mysqli_connect('localhost', 'root', '', 'Kursverwaltungssystem');

if ($conn -> connect_error) {
    echo "Connection failed: ".$conn -> connect_error;
}

if (isset($_POST['isDelete']) && $_POST['isDelete'] == "true") {
    $sql = "DELETE FROM `dozenten`
    WHERE dozenten.idDozenten = " . $_POST['dozentID'];
    $conn -> query($sql);
  echo " "; //to trigger reload in ajax
    mysqli_close($conn);
} else {

    $isUpdate = $_POST['isUpdate'];
    if ($isUpdate == "true") {
        $dozentID = $_POST['dozentID'];
    }
    $dozentName = $_POST['dozentName'];
    $dozentEmail = $_POST['dozentEmail'];
    $dozentFachgebiet = $_POST['dozentFachgebiet'];
    $dozentQualifikation = $_POST['dozentQualifikation'];
    $dozentPasswort = $_POST['dozentPasswort'];
    if($dozentPasswort != ""){
        $dozentPasswort = password_hash('$dozentPasswort', PASSWORD_DEFAULT);
    }
    
    if ($isUpdate == "true") {
        $sql = "UPDATE dozenten
        SET dozenten.name = '$dozentName',
            dozenten.email = '$dozentEmail',
            dozenten.fachgebiet = '$dozentFachgebiet',
            dozenten.qualifikationen = '$dozentQualifikation'";
            
        if($dozentPasswort != ""){
         $sql .= ", dozenten.passwort = '$dozentPasswort' ";
        }
         $sql .= "WHERE
        dozenten.idDozenten = $dozentID; ";
    } else {
        $sql = "INSERT INTO `dozenten` (`dozenten`.`name`, dozenten.email, dozenten.fachgebiet, dozenten.qualifikationen, dozenten.passwort) 
        VALUES ('$dozentName', '$dozentEmail', '$dozentFachgebiet', '$dozentQualifikation', '$dozentPasswort');";

}

    if ($conn -> query($sql)) {
        if ($isUpdate == "true") {
            $outputHTML = "Dozent mit DozentenID = $dozentID wurde geupdatet.";
        } else {
            $outputHTML = "Dozent $dozentName wurde erstellt.";
        }
    } else {
        $outputHTML = "Error: ".$sql. "<br>".$conn -> error;
    }
    mysqli_close($conn);

echo json_encode($outputHTML);
}
?>