<?php include('header.php');
include('nav.php');
include('data.php');
?>
<html>
<script>
function phpCreateDozent() {
 var dozentName = document.getElementById("neuDozentName").value;
 var dozentEmail = document.getElementById("neuDozentEmail").value;
 var dozentFachgebiet = document.getElementById("neuDozentFachgebiet").value;
 var dozentQualifikation = document.getElementById("neuDozentQualifikation").value;
 var dozentPasswort = document.getElementById("neuDozentPasswort").value;

 if(dozentName == "" || dozentEmail == "" || dozentPasswort == ""){
    $("#output").html("Bitte keine wichtigen Felder leer lassen!");
    return false;
 }
$.ajax({
    type: "POST",  //type of method
    url: "/Kursverwaltungssystem/updateInsertDozent.php",  //your page
    data: {dozentName: dozentName, dozentEmail: dozentEmail, dozentFachgebiet: dozentFachgebiet,
        dozentQualifikation: dozentQualifikation, dozentPasswort: dozentPasswort, isUpdate: false
    },// passing the values
    success: function (res) {
        if (res) {
            window.location.reload(true);
        }
    }
});

return false;
}


function phpUpdateDozent(dozentID) {
 var dozentName = document.getElementById("dozentName").value;
 var dozentEmail = document.getElementById("dozentEmail").value;
 var dozentFachgebiet = document.getElementById("dozentFachgebiet").value;
 var dozentQualifikation = document.getElementById("dozentQualifikation").value;
 var dozentPasswort = document.getElementById("dozentPasswort").value;

$.ajax({
    type: "POST",  //type of method
    url: "/Kursverwaltungssystem/updateInsertDozent.php",  //your page
    data: {dozentID: dozentID, dozentName: dozentName, dozentEmail: dozentEmail, dozentFachgebiet: dozentFachgebiet,
        dozentQualifikation: dozentQualifikation, dozentPasswort: dozentPasswort, isUpdate: true
    },// passing the values},// passing the values
    success: function (res) {
        if (res) {
            $("#output").html(JSON.parse(res));
        }
    }
});

return false;
}


function phpDeleteDozent(dozentID) {
$.ajax({
    type: "POST",  //type of method
    url: "/Kursverwaltungssystem/updateInsertDozent.php",  //your page
    data: {dozentID: dozentID, isDelete: true},// passing the values
    success: function (res) {
        if (res) {
            window.location.reload(true);
        }
    }
});

return false;
}

</script>
<body>
    <h1>Dozentenverwaltung</h1>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">
                    <h3>Dozenten ID</h3>
                </th>
                <th scope="col">
                    <h3>Name</h3>
                </th>
                <th scope="col">
                    <h3>E-Mail</h3>
                </th>
                <th scope="col">
                    <h3>Fachgebiet</h3>
                </th>
                <th scope="col">
                    <h3>Qualifikationen</h3>
                </th>
                <th scope="col">
                    <h3>Passwort</h3>
                </th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td> Neuer Dozent</td>
                <td> <input class='form-control' id='neuDozentName' name='neuDozentName'  placeholder='Name'/></td>
                <td> <input class='form-control' id='neuDozentEmail' name='neuDozentEmail'  placeholder='Email'/></td>
                <td> <input class='form-control' id='neuDozentFachgebiet' name='neuDozentFachgebiet'  placeholder='Fachgebiet'/>
                </td>
                <td> <input class='form-control' id='neuDozentQualifikation' name='neuDozentQualifikation'  placeholder='Qualifikation'/>
                </td>
                <td> <input class='form-control' id='neuDozentPasswort' name='neuDozentPasswort'  placeholder='Passwort'/>
                </td>
                <td> <button type='button' class='btn btn-primary' onclick='phpCreateDozent()'>Erstellen</button> </td>
            </tr>
            <tr>
                <td colspan="4"></td>
            </tr>
<?php

for ($x = 0; $x < sizeof($rowsDozenten); $x++) {
    echo "<tr>";
    echo "<td>" . $rowsDozenten[$x][0] . "</td>";
    echo "<td> <input class='form-control' id='dozentName' name='dozentName'  value='" . $rowsDozenten[$x][1] . "'/></td>";
    echo "<td> <input class='form-control' id='dozentEmail' name='dozentEmail'  value='" . $rowsDozenten[$x][2] . "'/></td>";
    echo "<td> <input class='form-control' id='dozentFachgebiet' name='dozentFachgebiet'  value='" . $rowsDozenten[$x][3] . "'/></td>";
    echo "<td> <input class='form-control' id='dozentQualifikation' name='dozentQualifikation'  value='" . $rowsDozenten[$x][4] . "'/></td>";
    echo "<td> <input class='form-control' id='dozentPasswort' name='dozentPasswort' placeholder='Passwort'/></td>";
   
    echo "<td> <button type='button' class='btn btn-primary' onclick='phpUpdateDozent(" . $rowsDozenten[$x][0] . ")'>Updaten</button> </td>";
    echo "<td> <button type='button' class='btn btn-primary' onclick='phpDeleteDozent(" . $rowsDozenten[$x][0] . ")'>Löschen</button> </td></tr>";
}
?>

        </tbody>
    </table>
    
    <label name="output" id="output"></label>
</body >

</html >