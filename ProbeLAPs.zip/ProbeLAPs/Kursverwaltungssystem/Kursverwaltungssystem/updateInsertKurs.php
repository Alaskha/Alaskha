<?php include('data.php');


$conn = mysqli_connect('localhost', 'root', '', 'Kursverwaltungssystem');

if ($conn -> connect_error) {
    echo "Connection failed: ".$conn -> connect_error;
}


if (isset($_POST['isDelete']) && $_POST['isDelete'] == "true") {
    $sql = "DELETE FROM `kurs`
    WHERE kurs.idKurs = " . $_POST['kursID'];
    $conn -> query($sql);
  echo " "; //to trigger reload in ajax
    mysqli_close($conn);
} else {

    $isUpdate = $_POST['isUpdate'];
    if ($isUpdate == "true") {
        $kursID = $_POST['kursID'];
    }
    $kursName = $_POST['kursName'];
    $kursDozent = $_POST['kursDozent'];

    if ($isUpdate == "true") {
        $sql = "UPDATE kurs
        SET kurs.name = '$kursName',
            kurs.Dozenten_idDozenten = $kursDozent
        WHERE
        kurs.idKurs = $kursID; ";
    } else {
        $sql = "INSERT INTO `kurs` (`kurs`.`name`, `Dozenten_idDozenten`) VALUES ('$kursName', $kursDozent);";
    }

    if ($conn -> query($sql)) {
        if ($isUpdate == "true") {
            $outputHTML = "Kurs mit KursID = $kursID wurde geupdatet.";
        } else {
            $outputHTML = "Kurs $kursName wurde erstellt.";
        }
    } else {
        $outputHTML = "Error: ".$sql. "<br>".$conn -> error;
    }
    mysqli_close($conn);

echo json_encode($outputHTML);
}
?>