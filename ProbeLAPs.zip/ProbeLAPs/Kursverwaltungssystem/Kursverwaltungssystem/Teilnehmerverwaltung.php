<?php include('header.php');
include('nav.php');
include('data.php');
?>
<html>
<script>
    function phpAnmelden() {
    /* var divStations = document.getElementById("dom-target-stations");
     var divDays = document.getElementById("dom-target-days");
     var stationsData = JSON.parse(divStations.textContent);
     var daysData = JSON.parse(divDays.textContent);*/

    var teilnehmerID = $('#teilnehmer option:selected').val();
    var kursID = $('#kurs option:selected').val();

    $.ajax({
        type: "POST",  //type of method
        url: "/Kursverwaltungssystem/anAbmeldenKursTeilnehmer.php",  //your page
        data: { teilnehmerID: teilnehmerID, kursID: kursID, isAnmeldung: true},// passing the values
        success: function (res) {
            if (res) {
                $("#output").html(JSON.parse(res));
            }
        }
    });

    return false;
}

    function phpAbmelden() {
    var teilnehmerID = $('#teilnehmer option:selected').val();
    var kursID = $('#kurs option:selected').val();

    $.ajax({
        type: "POST",  //type of method
        url: "/Kursverwaltungssystem/anAbmeldenKursTeilnehmer.php",  //your page
        data: { teilnehmerID: teilnehmerID, kursID: kursID, isAnmeldung: false},// passing the values
        success: function (res) {
            if (res) {
                $("#output").html(JSON.parse(res));
            }
        }
    });

    return false;
}
</script>

<body>
    <h1>Teilnehmerverwaltung</h1>
    <form onsubmit="return phpAnmelden()" method="POST">
        <div class="form-group">
            <fieldset>
                <label for="teilnehmer">Teilnehmer:</label>
                <select name="teilnehmer" id="teilnehmer">
<?php
for ($x = 0; $x < sizeof($rowsTeilnehmer); $x++) {
    echo "<option value=".$rowsTeilnehmer [$x][0].">".$rowsTeilnehmer [$x][1]."</option>";
}
?> 
          </select>
            </fieldset>
            <fieldset>
                <label for="kurs">Kurs:</label>
                <select name="kurs" id="kurs">
<?php
for ($x = 0; $x < sizeof($rowsKurs); $x++) {
    echo "<option value=".$rowsKurs[$x][0].">".$rowsKurs[$x][1]."</option>";
}
?>
            </select>
            </fieldset>
        </div>
        <button type="submit" class="btn btn-primary">Anmelden</button>
        <button type="button" class="btn btn-primary" onclick="phpAbmelden()">Abmelden</button>
    </form>
    <label name="output" id="output"></label>
    </div>
</body>

</html>