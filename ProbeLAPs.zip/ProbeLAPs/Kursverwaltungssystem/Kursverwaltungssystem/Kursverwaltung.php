<?php include('header.php');
include('nav.php');
include('data.php');
?>
<html>
<script>

function phpUpdateKurs(kursID) {
/* var divStations = document.getElementById("dom-target-stations");
 var divDays = document.getElementById("dom-target-days");
 var stationsData = JSON.parse(divStations.textContent);
 var daysData = JSON.parse(divDays.textContent);*/

 var kursName = document.getElementById("kursName").value;
 var kursDozent = $('#kursDozenten option:selected').val();

$.ajax({
    type: "POST",  //type of method
    url: "/Kursverwaltungssystem/updateInsertKurs.php",  //your page
    data: { kursID: kursID, kursName: kursName, kursDozent: kursDozent, isUpdate: true},// passing the values
    success: function (res) {
        if (res) {
            $("#output").html(JSON.parse(res));
        }
    }
});

return false;
}

function phpCreateKurs() {
 var kursName = document.getElementById("neuKursName").value;
 var kursDozent = $('#neuKursDozenten option:selected').val();


$.ajax({
    type: "POST",  //type of method
    url: "/Kursverwaltungssystem/updateInsertKurs.php",  //your page
    data: {kursName: kursName, kursDozent: kursDozent, isUpdate: false},// passing the values
    success: function (res) {
        if (res) {
            window.location.reload(true);
        }
    }
});

return false;
}

function phpDeleteKurs(kursID) {
$.ajax({
    type: "POST",  //type of method
    url: "/Kursverwaltungssystem/updateInsertKurs.php",  //your page
    data: {kursID: kursID, isDelete: true},// passing the values
    success: function (res) {
        if (res) {
            window.location.reload(true);
        }
    }
});

return false;
}

</script>
<body>
<h1>Kursverwaltung</h1>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">
                    <h3>Kurs ID</h3>
                </th>
                <th scope="col">
                    <h3>Kurs</h3>
                </th>
                <th scope="col">
                    <h3>Dozent</h3>
                </th>
            </tr>
        </thead>
        <tbody>
            
<tr><td> NeuerKurs</td>
<td> <input class='form-control' id='neuKursName' name='neuKursName'  placeholder='KursName' required/></td> 
<td>          
    <select name="neuKursDozenten" id="neuKursDozenten">
<?php
for ($x = 0; $x < sizeof($rowsDozenten); $x++) {
    echo "<option value=".$rowsDozenten [$x][0].">".$rowsDozenten [$x][1]."</option>";
}
?> 
          </select>
        </td> 
        <td> <button type='button' class='btn btn-primary' onclick='phpCreateKurs()'>Erstellen</button> </td>
    </tr>
    <tr><td colspan="4"></td></tr>
<?php

for ($x = 0; $x < sizeof($rowsKurs); $x++) {
    echo "<tr>";
    echo "<td>" . $rowsKurs[$x][0] . "</td>";
    echo "<td> <input class='form-control' id='kursName' name='kursName'  value='" . $rowsKurs[$x][1] . "'/></td>";
    
    $selectHTML = "<td><select name='kursDozenten' id='kursDozenten'>";
    for ($j = 0; $j < sizeof($rowsDozenten); $j++) {
      if(stripos($rowsDozenten[$j][1], $rowsKurs[$x][2]) !== FALSE){
        $selectHTML .= "<option selected='selected' value=".$rowsDozenten[$j][0].">".$rowsDozenten[$j][1]."</option>";
      }else{
        $selectHTML .= "<option value=".$rowsDozenten[$j][0].">".$rowsDozenten[$j][1]."</option>";
      }
    }
    $selectHTML .=  "</select></td>";
    echo $selectHTML;

    echo "<td> <button type='button' class='btn btn-primary' onclick='phpUpdateKurs(" . $rowsKurs[$x][0] . ")'>Updaten</button> </td>";
    echo "<td> <button type='button' class='btn btn-primary' onclick='phpDeleteKurs(" . $rowsKurs[$x][0] . ")'>Löschen</button> </td></tr>";
}
?>

        </tbody>
    </table>
    
    <label name="output" id="output"></label>
</body >

</html >