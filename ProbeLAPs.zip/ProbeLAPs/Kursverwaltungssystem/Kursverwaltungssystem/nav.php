<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Kursübersicht.php">Kursübersicht</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Dozentenverwaltung.php">Dozentenverwaltung</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Kursverwaltung.php">Kursverwaltung</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Teilnehmerverwaltung.php">Teilnehmerverwaltung</a>
        </li>
      </ul>
    </div>
  </div>
</nav>