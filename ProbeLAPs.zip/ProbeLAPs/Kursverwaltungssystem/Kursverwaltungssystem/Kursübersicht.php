<?php include('header.php');
include('nav.php');
include('data.php');
?>
<html>
<script>

function phpAnmelden(kursID) {
/* var divStations = document.getElementById("dom-target-stations");
 var divDays = document.getElementById("dom-target-days");
 var stationsData = JSON.parse(divStations.textContent);
 var daysData = JSON.parse(divDays.textContent);*/

var teilnehmerID = $('#teilnehmer option:selected').val();

$.ajax({
    type: "POST",  //type of method
    url: "/Kursverwaltungssystem/anAbmeldenKursTeilnehmer.php",  //your page
    data: { teilnehmerID: teilnehmerID, kursID: kursID, isAnmeldung: true},// passing the values
    success: function (res) {
        if (res) {
            $("#output").html(JSON.parse(res));
        }
    }
});

return false;
}
</script>
<body>
<h1>Kursübersicht</h1>
<fieldset>
          <label for="teilnehmer">Teilnehmer:</label>
          <select name="teilnehmer" id="teilnehmer">
<?php
for ($x = 0; $x < sizeof($rowsTeilnehmer); $x++) {
    echo "<option value=".$rowsTeilnehmer [$x][0].">".$rowsTeilnehmer [$x][1]."</option>";
}
?> 
          </select>
        </fieldset>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">
                    <h3>Kurs ID</h3>
                </th>
                <th scope="col">
                    <h3>Kurs</h3>
                </th>
                <th scope="col">
                    <h3>Dozent</h3>
                </th>
            </tr>
        </thead>
        <tbody>
<?php
$j = 0;
for ($x = 0; $x < sizeof($rowsKurs); $x++) {
    echo "<tr>";
    echo "<td>" . $rowsKurs[$x][0] . "</td>";
    echo "<td>" . $rowsKurs[$x][1] . "</td>";
    echo "<td>" . $rowsKurs[$x][2] . "</td>";
    echo "<td> <button type='button' class='btn btn-primary' onclick='phpAnmelden(" . $rowsKurs[$x][0] . ")'>Anmelden</button> </td>";
}
?>
        </tbody>
    </table>
    
    <label name="output" id="output"></label>
</body>

</html>