<?php

$conn = mysqli_connect('localhost', 'root', '', 'Kursverwaltungssystem');

if ($conn -> connect_error) {
        echo "Connection failed: ".$conn -> connect_error;
}
$sql = "SELECT kurs.idKurs, kurs.name, dozenten.name FROM kurs INNER JOIN dozenten ON dozenten.idDozenten = kurs.Dozenten_idDozenten;";
$result = $conn -> query($sql);
$rowsKurs = mysqli_fetch_all($result, MYSQLI_NUM);

$sql = "SELECT dozenten.idDozenten, dozenten.name, dozenten.email, dozenten.fachgebiet, dozenten.qualifikationen, dozenten.passwort FROM dozenten;";
$result = $conn -> query($sql);
$rowsDozenten = mysqli_fetch_all($result, MYSQLI_NUM);

$sql = "SELECT teilnehmer.idTeilnehmer, teilnehmer.name FROM teilnehmer;";
$result = $conn -> query($sql);
$rowsTeilnehmer = mysqli_fetch_all($result, MYSQLI_NUM);

mysqli_close($conn);
    ?>