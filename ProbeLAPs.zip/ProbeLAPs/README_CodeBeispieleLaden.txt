Viele der Code-Beispiele verwenden Links mit hart-codierten Pfaden wie:
"/LAP2022/TableDisplay.php"
Dadurch wird dann "http://localhost:81/LAP2022/TableDisplay.php" aufgerufen.
Wenn bei dir im XAMPP-Pfad der Code in einem anders benannten Ordner ist, wird das Programm die gesuchte Datei, "TableDisplay.php", nicht finden können.

Also muss der Code mitsamt Ordner in den "C:\xampp\htdocs"-Pfad kopiert werden, sodass die Webseite sofort funktioniert.

Somit muss für das Code-Beispiel der Lösung_2 von "Fahrradverleih" der gesamte Ordner "LAP2022" in den XAMPP-Pfad kopiert werden.
"C:\xampp\htdocs\LAP2022\TableDisplay.php"