<?php
include('header.php');

// Get `idbenutzer` from GET
$idbenutzer = $_GET["idbenutzer"];

// Database connection
$conn = mysqli_connect("localhost", "root", "", "onlineshop");

// Fetch products purchased by the user
$sql = "
    SELECT DISTINCT products.id, products.name
    FROM bestellung_hat_produkt
    INNER JOIN bestellung ON bestellung_hat_produkt.idbestellung = bestellung.idbestellung
    INNER JOIN products ON bestellung_hat_produkt.idprodukt = products.id
    WHERE bestellung.idbenutzer = $idbenutzer
";
$result = mysqli_query($conn, $sql);
$allproducts = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productID = $_POST["product_id"];
    $rating = $_POST["rating"];
    $reviewText = $_POST["review_text"];

    // Validate product ownership
    $sql2 = "
        SELECT bestellung_hat_produkt.idbestellung
        FROM bestellung_hat_produkt
        INNER JOIN bestellung ON bestellung_hat_produkt.idbestellung = bestellung.idbestellung
        WHERE bestellung_hat_produkt.idprodukt = $productID AND bestellung.idbenutzer = $idbenutzer
        LIMIT 1
    ";
    $result2 = mysqli_query($conn, $sql2);

    if (mysqli_num_rows($result2) > 0) {
        // Insert the review
        $sql3 = "
            INSERT INTO reviews (bewertung, beschreibung, idproduct, idbenutzer)
            VALUES ($rating, '$reviewText', $productID, $idbenutzer)
        ";
        $result3 = mysqli_query($conn, $sql3);

    }
}

$sql= "SELECT reviews.idreview, products.name, reviews.bewertung, reviews.beschreibung, reviews.idbenutzer FROM reviews INNER JOIN products ON reviews.idproduct = products.id WHERE reviews.idbenutzer = $idbenutzer";
$result = mysqli_query($conn, $sql);
$reviews = mysqli_fetch_all($result);

?>

<html>
<body>
<h2>Review</h2>

<form method="POST">
    <label for="product_id">Product:</label>
    <select name="product_id" required>
        <?php foreach ($allproducts as $product): ?>
            <option value="<?= $product['id'] ?>"><?= $product['name'] ?></option>
        <?php endforeach; ?>
    </select>

    <label for="rating">Ratings:</label>
    <input type="number" name="rating" min="1" max="5" required>

    <label for="review_text">Review:</label>
    <textarea name="review_text" required></textarea>

    <button type="submit">Submit</button>
</form>

<table width="80%">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Bewertungen</th>
                <th>Review</th>
                <th>User ID</th>
            </tr>

            <?php
            // foreach($rows as $row)
            foreach ($reviews as $review) {
                echo ("<tr>");
                echo ("<td>$review[0]</td>");
                echo ("<td>$review[1]</td>");
                echo ("<td>$review[2]</td>");
                echo ("<td>$review[3]</td>");
                echo ("<td>$review[4]</td>");
                echo ("</tr>");
            }

            ?>
        </table>


</body>
</html>
