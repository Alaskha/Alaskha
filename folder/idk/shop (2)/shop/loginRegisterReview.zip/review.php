<?php
include('header.php');
session_start();

// Database connection
$conn = mysqli_connect("localhost", "root", "", "onlineshop");

// Check if user is logged in
if (!isset($_SESSION['idprofil'])) {
    die("Please log in to access this page.");
}

$idbenutzer = $_SESSION['idprofil'];

// Fetch products purchased by the user
$sql = "SELECT DISTINCT products.id AS product_id, products.name AS product_name FROM bestellung_hat_produkt INNER JOIN bestellung ON bestellung_hat_produkt.idbestellung = bestellung.idbestellung INNER JOIN products ON bestellung_hat_produkt.idprodukt = products.id WHERE bestellung.idbenutzer = $idbenutzer";
$result = $conn->query($sql);
$products = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = intval($_POST['product_id']);
    $rating = intval($_POST['rating']);
    $reviewText = mysqli_real_escape_string($conn, $_POST['review_text']); // Sanitize input

    // Validate product ownership
    $ownershipCheck = "SELECT 1 FROM bestellung_hat_produkt INNER JOIN bestellung ON bestellung_hat_produkt.idbestellung = bestellung.idbestellung WHERE bestellung.idbenutzer = $idbenutzer AND bestellung_hat_produkt.idprodukt = $productId LIMIT 1";
    $ownershipResult = $conn->query($ownershipCheck);

    if ($ownershipResult->num_rows > 0) {
        // Insert review
        $insertReview = "INSERT INTO reviews (bewertung, beschreibung, idproduct, idbenutzer) VALUES ($rating, '$reviewText', $productId, $idbenutzer)
        ";
        if ($conn->query($insertReview)) {
            echo "Review submitted successfully!";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "You cannot review this product as you have not purchased it.";
    }
}
?>

<html>
<body>
<h2>Submit a Review</h2>

<!-- Dropdown to select purchased products -->
<form method="POST">
    <label for="product_id">Select Product:</label>
    <select name="product_id" required>
        <?php foreach ($products as $product): ?>
            <option value="<?= $product['product_id'] ?>"><?= htmlspecialchars($product['product_name']) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="rating">Rating (1-5):</label>
    <input type="number" name="rating" min="1" max="5" required>

    <label for="review_text">Review:</label>
    <textarea name="review_text" required></textarea>

    <button type="submit">Submit Review</button>
</form>

</body>
</html>
