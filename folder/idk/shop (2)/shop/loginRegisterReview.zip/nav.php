<!-- < ?php
session_start(); // Start the session to access stored variables
?>

<html>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Login.php">Login</a>
        </li>
        <li class="nav-item">
          < ?php isset($_SESSION['benutzer']) && isset($_SESSION['bestellung']) ;
          $benutzer = $_SESSION['benutzer'];
          $bestellung = $_SESSION['bestellung'];
          $link = $benutzer[0] . '&bestellID=' . $bestellung[0];?>
          <a class="nav-link active" aria-current="page" href="bestellungen.php?idbenutzer=< ?php echo $link; ?>">Bestellungen</a>
          
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="warenkorb.php">Warenkorb</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

</html> -->

<!-- < ?php
session_start(); // Start the session to access stored variables
include('loginRegister.php');
?>

<html>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="Login.php">Login</a>
      </li>
      <li class="nav-item">
        < ?php
        // Check if session variables are set
        isset($_SESSION['benutzer']) && isset($_SESSION['bestellung']) ;
            $benutzer = $_SESSION['benutzer'];
            $bestellung = $_SESSION['bestellung'];
            $link = $benutzer[0] . '&bestellID=' . $bestellung[0];?>
          <a class="nav-link active" aria-current="page" href="bestellungen.php?idbenutzer=< ?php echo $link; ?>">Bestellungen</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" aria-current="page" href="warenkorb.php">Warenkorb</a>
      </li>
    </ul>
  </div>
</nav>
</html> -->
