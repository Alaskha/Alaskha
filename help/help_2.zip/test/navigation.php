<nav class="navigation">
    <ul class="navigation-list">
        <li class="navigation-item"><a href="#">Home</a></li>
        <li class="navigation-item"><a href="#">Dashboard</a></li>
        <li class="navigation-item"><a href="#">About</a></li>
        <!-- Add more navigation items as needed -->
    </ul>
</nav>
