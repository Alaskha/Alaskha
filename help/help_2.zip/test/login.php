<?php
// This is a simple example with hardcoded credentials.
$valid_username = 'user123';
$valid_password = 'password123';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    /*     // Simple validation
    if ($username === $valid_username && $password === $valid_password) {
        // Successful login
        echo "<h2>Welcome, $username!</h2>";
    } else {
        // Failed login
        echo "<h2>Invalid username or password. Please try again.</h2>";
    }
 */
    if ($username === $valid_username && $password === $valid_password) {
        // Login successful, redirect to a dashboard or homepage
        header("Location: http://localhost/dashboard.php");
        exit();
    } else {
        // Login failed, display an error message
        $error_message = "Invalid username or password.";
    }
}
