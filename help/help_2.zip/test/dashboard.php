<!DOCTYPE html>
<html data-theme="dark">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard</title>
  <link href="node_modules\daisyui\dist\full.css" rel="stylesheet" />
  <style>
    /* Custom Styles for Dashboard */
    body {
      background-color: #f3f4f6;
      font-family: Arial, sans-serif;
    }

    .dashboard-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 20px;
    }

    .dashboard-welcome {
      font-size: 24px;
      font-weight: bold;
      color: #374151;
      margin-bottom: 20px;
    }

    .dashboard-card {
      background-color: rgba(255, 255, 255, 0.8);
      backdrop-filter: blur(5px);
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
      margin-bottom: 20px;
    }

    .logout-btn {
      background-color: #dc2626;
      color: #fff;
      border: none;
      border-radius: 4px;
      padding: 10px 20px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .logout-btn:hover {
      background-color: #b91c1c;
    }

    .navigation {
      background-color: #764ba2;
      padding: 10px;
    }

    .navigation-list {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      justify-content: center;
    }

    .navigation-item {
      margin-right: 20px;
    }

    .navigation-item:last-child {
      margin-right: 0;
    }

    .navigation-item a {
      color: #fff;
      text-decoration: none;
      padding: 5px 10px;
    }

    .navigation-item a:hover {
      background-color: #6b7280;
      border-radius: 4px;
    }
  </style>
</head>

<body class="min-h-screen">
  <div class="navigation-placeholder"></div>
  <?php include 'navigation.php'; ?>

  <div class="dashboard-container">
    <h2 class="dashboard-welcome">Welcome to the Dashboard!</h2>
    <div class="dashboard-card">
      <h3>Card 1</h3>
      <p>This is some content for Card 1.</p>
    </div>
    <div class="dashboard-card">
      <h3>Card 2</h3>
      <p>This is some content for Card 2.</p>
    </div>
    <div class="dashboard-card">
      <h3>Card 3</h3>
      <p>This is some content for Card 3.</p>
    </div>
    <button class="logout-btn" onclick="location.href='login.html'">
      Logout
    </button>
  </div>
</body>

</html>