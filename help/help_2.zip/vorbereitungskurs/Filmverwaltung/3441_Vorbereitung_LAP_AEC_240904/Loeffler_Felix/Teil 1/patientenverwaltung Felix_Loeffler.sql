-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 04. Sep 2024 um 11:14
-- Server-Version: 10.4.32-MariaDB
-- PHP-Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `patientenverwaltung`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `befunde`
--

CREATE TABLE `befunde` (
  `id` int(10) UNSIGNED NOT NULL,
  `fk_patient` int(10) UNSIGNED NOT NULL,
  `fk_termin` int(10) UNSIGNED NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `befund_medikament`
--

CREATE TABLE `befund_medikament` (
  `fk_befund` int(10) UNSIGNED NOT NULL,
  `fk_medikament` int(10) UNSIGNED NOT NULL,
  `dosierung` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `emailadressenpatient`
--

CREATE TABLE `emailadressenpatient` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(100) NOT NULL,
  `fk_patient` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `laender`
--

CREATE TABLE `laender` (
  `id` int(10) UNSIGNED NOT NULL,
  `abkuerzung` varchar(3) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `laender`
--

INSERT INTO `laender` (`id`, `abkuerzung`, `name`) VALUES
(1, 'AUT', 'Österreich'),
(2, 'GER', 'Deutschland');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `medikamente`
--

CREATE TABLE `medikamente` (
  `id` int(10) UNSIGNED NOT NULL,
  `bezeichnung` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `medikamente`
--

INSERT INTO `medikamente` (`id`, `bezeichnung`) VALUES
(1, 'Aspirin'),
(2, 'Parkemed');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `patienten`
--

CREATE TABLE `patienten` (
  `id` int(10) UNSIGNED NOT NULL,
  `vorname` varchar(50) NOT NULL,
  `nachname` varchar(50) NOT NULL,
  `svnr` bigint(10) UNSIGNED NOT NULL,
  `fk_sozialversicherung` int(10) UNSIGNED NOT NULL,
  `fk_patientOrt` int(10) UNSIGNED NOT NULL,
  `strasse` varchar(100) NOT NULL,
  `hausnr` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `postleitzahlen`
--

CREATE TABLE `postleitzahlen` (
  `id` int(10) UNSIGNED NOT NULL,
  `plz` varchar(5) NOT NULL,
  `ort` varchar(50) NOT NULL,
  `fk_land` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `postleitzahlen`
--

INSERT INTO `postleitzahlen` (`id`, `plz`, `ort`, `fk_land`) VALUES
(0, '11111', 'Ort2', 2),
(1, '12345', 'Ort1', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sozialversicherungen`
--

CREATE TABLE `sozialversicherungen` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `fk_versicherungOrt` int(10) UNSIGNED NOT NULL,
  `strasse` varchar(100) NOT NULL,
  `hausnr` varchar(4) NOT NULL,
  `telnr` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `telefonnummernpatient`
--

CREATE TABLE `telefonnummernpatient` (
  `id` int(10) UNSIGNED NOT NULL,
  `telnr` varchar(50) NOT NULL,
  `fk_patient` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `termine`
--

CREATE TABLE `termine` (
  `id` int(10) UNSIGNED NOT NULL,
  `termin` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `termine`
--

INSERT INTO `termine` (`id`, `termin`) VALUES
(1, '2024-09-02 10:54:32'),
(2, '2024-09-04 00:00:00');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `befunde`
--
ALTER TABLE `befunde`
  ADD PRIMARY KEY (`id`),
  ADD KEY `befund_patient` (`fk_patient`),
  ADD KEY `befund_termin` (`fk_termin`);

--
-- Indizes für die Tabelle `befund_medikament`
--
ALTER TABLE `befund_medikament`
  ADD KEY `fk_befund` (`fk_befund`),
  ADD KEY `fk_medikament` (`fk_medikament`);

--
-- Indizes für die Tabelle `emailadressenpatient`
--
ALTER TABLE `emailadressenpatient`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_emailadressenpatient_patient` (`fk_patient`);

--
-- Indizes für die Tabelle `laender`
--
ALTER TABLE `laender`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `medikamente`
--
ALTER TABLE `medikamente`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `patienten`
--
ALTER TABLE `patienten`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_patientOrt` (`fk_patientOrt`),
  ADD KEY `fk_sozialversicherung` (`fk_sozialversicherung`);

--
-- Indizes für die Tabelle `postleitzahlen`
--
ALTER TABLE `postleitzahlen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_land` (`fk_land`);

--
-- Indizes für die Tabelle `sozialversicherungen`
--
ALTER TABLE `sozialversicherungen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_versicherungOrt` (`fk_versicherungOrt`);

--
-- Indizes für die Tabelle `telefonnummernpatient`
--
ALTER TABLE `telefonnummernpatient`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_patient` (`fk_patient`);

--
-- Indizes für die Tabelle `termine`
--
ALTER TABLE `termine`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `befunde`
--
ALTER TABLE `befunde`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `emailadressenpatient`
--
ALTER TABLE `emailadressenpatient`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `laender`
--
ALTER TABLE `laender`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT für Tabelle `medikamente`
--
ALTER TABLE `medikamente`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT für Tabelle `patienten`
--
ALTER TABLE `patienten`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `sozialversicherungen`
--
ALTER TABLE `sozialversicherungen`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `telefonnummernpatient`
--
ALTER TABLE `telefonnummernpatient`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `termine`
--
ALTER TABLE `termine`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `befunde`
--
ALTER TABLE `befunde`
  ADD CONSTRAINT `befund_patient` FOREIGN KEY (`fk_patient`) REFERENCES `patienten` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `befund_termin` FOREIGN KEY (`fk_termin`) REFERENCES `termine` (`id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `befund_medikament`
--
ALTER TABLE `befund_medikament`
  ADD CONSTRAINT `fk_befund` FOREIGN KEY (`fk_befund`) REFERENCES `befunde` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_medikament` FOREIGN KEY (`fk_medikament`) REFERENCES `medikamente` (`id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `emailadressenpatient`
--
ALTER TABLE `emailadressenpatient`
  ADD CONSTRAINT `fk_emailadressenpatient_patient` FOREIGN KEY (`fk_patient`) REFERENCES `patienten` (`id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `patienten`
--
ALTER TABLE `patienten`
  ADD CONSTRAINT `fk_patientOrt` FOREIGN KEY (`fk_patientOrt`) REFERENCES `postleitzahlen` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sozialversicherung` FOREIGN KEY (`fk_sozialversicherung`) REFERENCES `sozialversicherungen` (`id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `postleitzahlen`
--
ALTER TABLE `postleitzahlen`
  ADD CONSTRAINT `fk_land` FOREIGN KEY (`fk_land`) REFERENCES `laender` (`id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `sozialversicherungen`
--
ALTER TABLE `sozialversicherungen`
  ADD CONSTRAINT `fk_versicherungOrt` FOREIGN KEY (`fk_versicherungOrt`) REFERENCES `postleitzahlen` (`id`) ON UPDATE CASCADE;

--
-- Constraints der Tabelle `telefonnummernpatient`
--
ALTER TABLE `telefonnummernpatient`
  ADD CONSTRAINT `fk_patient` FOREIGN KEY (`fk_patient`) REFERENCES `patienten` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
