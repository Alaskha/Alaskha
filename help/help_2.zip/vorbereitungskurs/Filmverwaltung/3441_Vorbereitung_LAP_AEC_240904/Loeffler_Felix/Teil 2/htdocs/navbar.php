<nav>
    <ul>
        <li><a href="index.html">Startseite</a></li>
        <li><a href="produzentensuche.php">Produzentensuche</a></li>
        <li><a href="schauspielersuche.php">Schauspielersuche</a></li>
    </ul>
</nav>