<?php
require_once("functions.php");

$conn = dbConnect();
$schauspieler = $_GET && isset($_GET["schauspieler"]) ? $_GET["schauspieler"] : "";

$sql = "SELECT
            filme.name as filmname,
            CONCAT_WS(' ', schauspieler.vorname, schauspieler.nachname) as ssName,
            f_s.fk_filme,
            f_s.fk_schauspieler,
            produzenten.name AS produzentname
        FROM filme
        JOIN filme_schauspieler f_s ON filme.id = f_s.fk_filme
        JOIN schauspieler ON schauspieler.id = f_s.fk_schauspieler
        JOIN produzenten ON filme.fk_produzent = produzenten.id
        WHERE CONCAT_WS(' ', schauspieler.vorname, schauspieler.nachname) LIKE '%" . $schauspieler . "%';";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schauspielersuche</title>
</head>
<body>
    <?php include("navbar.php") ?>
    <h1>Schauspielersuche</h1>
    <form action="schauspielersuche.php" method="get">
        <label for="schauspieler">Suche nach Schauspieler:</label>
        <input type="text" id="schauspieler" name="schauspieler" value = <?php echo $schauspieler ?>>
        <button type="submit">Suchen</button>
        <button type="reset">Abbrechen</button>
    </form>
    <?php 
    if (mysqli_num_rows($result)==0) {
        echo "<p>Keine Ergebnisse</p>";
    } else {
        echo (isset($result)) ? "<h2>Ergebnisse:</h2> " : "" ?>
    <table>
        <?php 
        if(isset($result)) {
            while($film = $result->fetch_object()) { 
                echo "<tr>" . 
                    "<td>" . $film->ssName . "</td>" . 
                    "<td>" . $film->filmname . "</td>" .
                    "<td>" . $film->produzentname . "</td>";
                "</tr>";
            }
        }
    } 
        ?>
    </table>
</body>
</html>