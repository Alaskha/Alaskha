<?php
require_once("functions.php");

$conn = dbConnect();
$produzent = $_GET && isset($_GET["produzent"]) ? $_GET["produzent"] : "";

$sql = "SELECT
            filme.name as filmname,
            produzenten.name as produzentenname
        FROM filme 
        JOIN produzenten ON filme.fk_produzent = produzenten.id
        WHERE produzenten.name LIKE '%" . $produzent ."%'";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produzentensuche</title>
</head>
<body>
    <?php include("navbar.php") ?>

    <h1>Produzentensuche</h1>
    <form action="produzentensuche.php" method="get">
        <label for="produzent">Suche nach Produktionsfirma:</label>
        <input type="text" id="produzent" name="produzent" value = <?php echo $produzent ?>>
        <button type="submit">Suchen</button>
        <button type="reset">Abbrechen</button>
    </form>
    <?php 
    if (mysqli_num_rows($result)==0) {
        echo "<p>Keine Ergebnisse</p>";
    } else {
    echo (isset($result)) ? "<h2>Ergebnisse:</h2> " : "" ?>
    <table>
        <?php while($film = $result->fetch_object()) { 
            echo "<tr>" . 
                "<td>" . $film->filmname . "</td>" . 
                "<td>" . $film->produzentenname . "</td>";
            "</tr>";
        }
    }
        ?>
    </table>
</body>
</html>