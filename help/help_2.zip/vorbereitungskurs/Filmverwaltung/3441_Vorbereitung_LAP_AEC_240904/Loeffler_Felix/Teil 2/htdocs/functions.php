<?php
function dbConnect () {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "filmverwaltung";

    $conn = mysqli_connect($servername, $username, $password, $database);

    if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    }
    return $conn;
}
?>