-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 11. Nov 2024 um 13:45
-- Server-Version: 10.4.21-MariaDB
-- PHP-Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `filmverwaltung`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `filme`
--

CREATE TABLE `filme` (
  `Song_ID` int(11) NOT NULL,
  `Titel` varchar(45) DEFAULT NULL,
  `Erscheinungs-Datum` date DEFAULT NULL,
  `Produktionsfirma_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `filme`
--

INSERT INTO `filme` (`Song_ID`, `Titel`, `Erscheinungs-Datum`, `Produktionsfirma_ID`) VALUES
(3, 'Dirty Dancing', '1987-08-21', 2),
(4, 'Sister Act', '1992-05-29', 3),
(5, 'Harry Potter u. der Stein der Weisen', '2001-11-23', 4),
(6, 'Casanova', '2006-02-09', 3),
(7, 'Die unendliche Geschichte', '1984-05-20', 1),
(8, 'Die Welle', '2008-03-13', 1),
(9, 'Krieg in Chinatown', '1987-09-25', 2),
(10, 'I Am Legend', '2008-01-10', 4),
(11, 'Transcendence', '2014-04-18', 4),
(12, 'Bruce Allmächtig', '2003-06-12', 2),
(13, 'Ghost - Nachricht von Sam', '1990-07-13', 5);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `produktionsfirma`
--

CREATE TABLE `produktionsfirma` (
  `Produktionsfirma_ID` int(11) NOT NULL,
  `Bezeichnung` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `produktionsfirma`
--

INSERT INTO `produktionsfirma` (`Produktionsfirma_ID`, `Bezeichnung`) VALUES
(1, 'Bavaria Filmstudios'),
(2, 'Great American Films'),
(3, 'Touchstones Pictures'),
(4, 'Warner Brothers Pictures'),
(5, 'Paramount Pictures');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schauspieler`
--

CREATE TABLE `schauspieler` (
  `id` int(11) NOT NULL,
  `Vorname` varchar(45) DEFAULT NULL,
  `Nachname` varchar(45) DEFAULT NULL,
  `Herkunpft` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `schauspieler`
--

INSERT INTO `schauspieler` (`id`, `Vorname`, `Nachname`, `Herkunpft`) VALUES
(1, 'Heath', 'Ledger', 'Australien'),
(2, 'Jürgen', 'Vogel', 'Deutschland'),
(3, 'Jerry', 'Orbach', 'USA'),
(4, 'Morgan', 'Freeman', 'USA'),
(5, 'Jennifer', 'Grey', 'USA'),
(6, 'Patrick', 'Swayze', 'USA'),
(7, 'Cynthia', 'Rhodes', 'USA'),
(8, 'Will', 'Smith', 'USA'),
(9, 'Emma', 'Thompson', 'England');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schauspieler_has_filme`
--

CREATE TABLE `schauspieler_has_filme` (
  `Schauspieler_id` int(11) NOT NULL,
  `Filme_Song_ID` int(11) NOT NULL,
  `Rolle` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `schauspieler_has_filme`
--

INSERT INTO `schauspieler_has_filme` (`Schauspieler_id`, `Filme_Song_ID`, `Rolle`) VALUES
(1, 6, 'Casanova'),
(2, 8, 'Rainer Wenger'),
(3, 3, 'Dr. Jake Houseman'),
(4, 11, 'Joseph Tagger'),
(4, 12, 'Gott'),
(5, 3, 'Frances \"Baby\" Houseman'),
(6, 3, 'Johnny Castle'),
(6, 13, 'Sam'),
(7, 3, 'Penny Johnson'),
(8, 10, 'Robert Neville'),
(9, 10, 'Dr. Alice Krippin');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `filme`
--
ALTER TABLE `filme`
  ADD PRIMARY KEY (`Song_ID`),
  ADD KEY `fk_Filme_Produktionsfirma_idx` (`Produktionsfirma_ID`);

--
-- Indizes für die Tabelle `produktionsfirma`
--
ALTER TABLE `produktionsfirma`
  ADD PRIMARY KEY (`Produktionsfirma_ID`);

--
-- Indizes für die Tabelle `schauspieler`
--
ALTER TABLE `schauspieler`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `schauspieler_has_filme`
--
ALTER TABLE `schauspieler_has_filme`
  ADD PRIMARY KEY (`Schauspieler_id`,`Filme_Song_ID`),
  ADD KEY `fk_Schauspieler_has_Filme_Filme1_idx` (`Filme_Song_ID`),
  ADD KEY `fk_Schauspieler_has_Filme_Schauspieler1_idx` (`Schauspieler_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `filme`
--
ALTER TABLE `filme`
  MODIFY `Song_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT für Tabelle `produktionsfirma`
--
ALTER TABLE `produktionsfirma`
  MODIFY `Produktionsfirma_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `schauspieler`
--
ALTER TABLE `schauspieler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `filme`
--
ALTER TABLE `filme`
  ADD CONSTRAINT `fk_Filme_Produktionsfirma` FOREIGN KEY (`Produktionsfirma_ID`) REFERENCES `produktionsfirma` (`Produktionsfirma_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `schauspieler_has_filme`
--
ALTER TABLE `schauspieler_has_filme`
  ADD CONSTRAINT `fk_Schauspieler_has_Filme_Filme1` FOREIGN KEY (`Filme_Song_ID`) REFERENCES `filme` (`Song_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Schauspieler_has_Filme_Schauspieler1` FOREIGN KEY (`Schauspieler_id`) REFERENCES `schauspieler` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
