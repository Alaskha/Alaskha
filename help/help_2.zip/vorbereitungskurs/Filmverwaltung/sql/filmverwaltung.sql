-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 11. Nov 2024 um 14:24
-- Server-Version: 10.4.21-MariaDB
-- PHP-Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `filmverwaltung`
--
CREATE DATABASE IF NOT EXISTS `filmverwaltung` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `filmverwaltung`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `film`
--
-- Erstellt am: 11. Nov 2024 um 13:21
-- Zuletzt aktualisiert: 11. Nov 2024 um 13:21
--

DROP TABLE IF EXISTS `film`;
CREATE TABLE `film` (
  `Film_ID` int(11) NOT NULL,
  `Titel` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Erscheinungs-Datum` date NOT NULL,
  `Produktionsfirma_ID` int(11) NOT NULL,
  `Actor_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONEN DER TABELLE `film`:
--   `Produktionsfirma_ID`
--       `produktionsfirma` -> `Produktionsfirma_ID`
--

--
-- Daten für Tabelle `film`
--

INSERT INTO `film` (`Film_ID`, `Titel`, `Erscheinungs-Datum`, `Produktionsfirma_ID`, `Actor_ID`) VALUES
(3000, 'Dirty Dancing', '1987-08-21', 2, 0),
(3001, 'Sister Act', '1992-05-29', 3, 0),
(3002, 'Harry Potter u. der Stein der Weisen', '2001-11-23', 4, 0),
(3003, 'Casanova', '2006-02-09', 3, 0),
(3004, 'Die unendliche Geschichte', '1984-09-25', 1, 0),
(3005, 'Die Welle', '2008-03-13', 1, 0),
(3006, 'Krieg in Chinatown', '1987-09-25', 2, 0),
(3007, 'I Am Legend', '2008-01-10', 4, 0),
(3008, 'Transcendence', '2014-04-18', 4, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `filme`
--
-- Erstellt am: 11. Nov 2024 um 13:23
-- Zuletzt aktualisiert: 11. Nov 2024 um 13:23
--

DROP TABLE IF EXISTS `filme`;
CREATE TABLE `filme` (
  `Song_ID` int(11) NOT NULL,
  `Titel` varchar(45) DEFAULT NULL,
  `Erscheinungs-Datum` date DEFAULT NULL,
  `Produktionsfirma_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- RELATIONEN DER TABELLE `filme`:
--

--
-- Daten für Tabelle `filme`
--

INSERT INTO `filme` (`Song_ID`, `Titel`, `Erscheinungs-Datum`, `Produktionsfirma_ID`) VALUES
(3, 'Dirty Dancing', '1987-08-21', 2),
(4, 'Sister Act', '1992-05-29', 3),
(5, 'Harry Potter u. der Stein der Weisen', '2001-11-23', 4),
(6, 'Casanova', '2006-02-09', 3),
(7, 'Die unendliche Geschichte', '1984-05-20', 1),
(8, 'Die Welle', '2008-03-13', 1),
(9, 'Krieg in Chinatown', '1987-09-25', 2),
(10, 'I Am Legend', '2008-01-10', 4),
(11, 'Transcendence', '2014-04-18', 4),
(12, 'Bruce Allmächtig', '2003-06-12', 2),
(13, 'Ghost - Nachricht von Sam', '1990-07-13', 5);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `produktionsfirma`
--
-- Erstellt am: 11. Nov 2024 um 12:03
-- Zuletzt aktualisiert: 11. Nov 2024 um 12:06
--

DROP TABLE IF EXISTS `produktionsfirma`;
CREATE TABLE `produktionsfirma` (
  `Produktionsfirma_ID` int(11) NOT NULL,
  `Bezeichnung` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONEN DER TABELLE `produktionsfirma`:
--

--
-- Daten für Tabelle `produktionsfirma`
--

INSERT INTO `produktionsfirma` (`Produktionsfirma_ID`, `Bezeichnung`) VALUES
(1, 'Bavaria Filmstudios'),
(2, 'Great American Films'),
(3, 'Touchstones Pictures'),
(4, 'Warner Brothers Pictures');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `schauspieler`
--
-- Erstellt am: 11. Nov 2024 um 13:21
--

DROP TABLE IF EXISTS `schauspieler`;
CREATE TABLE `schauspieler` (
  `ActorID` int(11) NOT NULL,
  `Vorname` varchar(255) NOT NULL,
  `Nachname` varchar(255) NOT NULL,
  `Herkunftsland` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONEN DER TABELLE `schauspieler`:
--   `ActorID`
--       `film` -> `Actor_ID`
--

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`Film_ID`),
  ADD KEY `fk_Produktionsfirma_Titel` (`Produktionsfirma_ID`),
  ADD KEY `Actor_ID` (`Actor_ID`);

--
-- Indizes für die Tabelle `produktionsfirma`
--
ALTER TABLE `produktionsfirma`
  ADD PRIMARY KEY (`Produktionsfirma_ID`);

--
-- Indizes für die Tabelle `schauspieler`
--
ALTER TABLE `schauspieler`
  ADD PRIMARY KEY (`ActorID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `film`
--
ALTER TABLE `film`
  MODIFY `Film_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3018;

--
-- AUTO_INCREMENT für Tabelle `produktionsfirma`
--
ALTER TABLE `produktionsfirma`
  MODIFY `Produktionsfirma_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `schauspieler`
--
ALTER TABLE `schauspieler`
  MODIFY `ActorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `film`
--
ALTER TABLE `film`
  ADD CONSTRAINT `fk_Produktionsfirma_Titel` FOREIGN KEY (`Produktionsfirma_ID`) REFERENCES `produktionsfirma` (`Produktionsfirma_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `schauspieler`
--
ALTER TABLE `schauspieler`
  ADD CONSTRAINT `fk_Actor_Film` FOREIGN KEY (`ActorID`) REFERENCES `film` (`Actor_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
