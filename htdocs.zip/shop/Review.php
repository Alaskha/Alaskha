<?php

include('header.php');
include('products.php');

$idbenutzer = $_GET["idbenutzer"];

$conn = mysqli_connect("localhost", "root", "", "onlineshop");

$sql = "SELECT `benutzerprofil`.`idprofil`, `products`.`id`,`products`.`name`, `bestellung`.`idbestellung` FROM `bestellung_hat_produkt` INNER JOIN `bestellung` ON `bestellung`.`idbestellung` = `bestellung_hat_produkt`.`idbestellung` INNER JOIN `products` ON `products`.`id` = `bestellung_hat_produkt`.`idprodukt` INNER JOIN `benutzerprofil` ON `bestellung`.`idbenutzer` WHERE `benutzerprofil`.`idprofil` = $idbenutzer;";

$result = mysqli_query($conn, $sql);
$allproducts = mysqli_fetch_all($result, MYSQLI_ASSOC);

$productID = $_POST["idprodukt"];
$rating = $_POST["bewertung"];
$desc = $_POST["beschreibung"];

$sql2 = "SELECT `bestellung_hat_produkt`.`idbestellung` 
FROM `bestellung_hat_produkt` 
INNER JOIN `bestellung` ON `bestellung_hat_produkt`.`idbestellung` = `bestellung`.`idbestellung` 
WHERE `bestellung_hat_produkt`.`idprodukt` = $productID AND `bestellung`.`idbenutzer` = $idbenutzer;";

$result2 = mysqli_query($conn, $sql2);

$sql3 = "INSERT INTO reviews (bewertung, beschreibung, idproduct, idbenutzer) 
VALUES ($rating, '$desc', $productID, $idbenutzer)";
$result3 = mysqli_query($conn, $sql3);

$sql4 ="SELECT reviews.idreview,reviews.idproduct, products.name, reviews.bewertung, reviews.beschreibung, reviews.idbenutzer from reviews INNER JOIN products on reviews.idproduct = products.id WHERE reviews.idbenutzer = $idbenutzer;";
$result4 = mysqli_query($conn,$sql4);

$reviews = mysqli_fetch_all($result4, MYSQLI_NUM);

?>



<html>
<style>
table, th, td {
  border: 1px solid black;
}
</style>

<body>

    <div>
        <table width="80%">
            <tr>
                <th>ID Review</th>
                <th>ID Produkt</th>
                <th>Name</th>
                <th>Bewertungen</th>
                <th>Beschreibung</th>

            </tr>

            <?php
            // foreach($rows as $row)
            foreach ($reviews as $review) {
                echo ("<tr>");
                echo ("<td>$review[0]</td>");
                echo ("<td>$review[1]</td>");
                echo ("<td>$review[2]</td>");
                echo ("<td>$review[3]</td>");
                echo ("<td>$review[4]</td>");
                echo ("</tr>");
            }

            //actors
            //bei drop down value mit $var ersetzen und produkt.name, [1] zeile

            ?>
        </table>
    </div>

<label name="output" id="output"></label>
</body>

</html>
