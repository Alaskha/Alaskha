<?php 



if ( isset($_POST['idFirstname'])) {
    
    $txtFirstname = $_POST['idFirstname'];
    
    echo "<h1> hallo " .$txtFirstname ."</h1>";

    
    echo '<a href=/formualr/simplemain.html>Zurück zum Anmeldeformular</a>';
}


?>