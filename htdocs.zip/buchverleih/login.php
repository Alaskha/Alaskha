<?php 
include ("header.php");


if (isset($_POST['inputEmail']) && isset($_POST['inputPass']))
{
    $txtEmail = $_POST['inputEmail'];
    $txtPasswort = $_POST['inputPass'];


if (check_login($txtEmail, $txtPasswort))
    {
        $con = mysqli_connect('localhost', 'root', '', 'buchverleih');
        $sql = "SELECT Vorname, Nachname FROM `benutzerprofile` WHERE EMail='$txtEmail' LIMIT 1;";
        $rs = mysqli_query($con, $sql);
        $row = $rs->fetch_array();
        mysqli_close($con);
        echo $row["Vorname"]. " ". $row["Nachname"] .nl2br("\n");

        


        echo "Logged in" . nl2br("\n");
        echo '<a href=/myOwnFiles/phpLogin.html>Zurück zum Anmeldeformular</a>';
    }else{
        echo "Username or Password couldn't be found in the database" . nl2br("\n");
        echo '<a href=/myOwnFiles/phpLogin.html>Zurück zum Anmeldeformular</a>';
    }
}
 
function check_login($email, $password){
    $con = mysqli_connect('localhost', 'root', '', 'buchverleih');
    $sql = "SELECT Password FROM `benutzerprofile` WHERE EMail='$email' LIMIT 1;";
    $rs = mysqli_query($con, $sql);
    $row = $rs->fetch_array();
    mysqli_close($con);
    
    return ($password == $row['Password']);
}

?>
