<?php 
include ("header.php");

?>

<script>
function buchSuche() {
    $(document).ready(function() {
        var genres = [
            <?php
            if (isset($_POST['search']))
            {
                $txtSearch = $_POST['search'];           
            
                {
                    $con = mysqli_connect('localhost', 'root', '', 'buchverleih');
                    $sql = "SELECT * FROM `buecher` WHERE Buchtitel LIKE '%{$txtSearch}%';";
                    $rs = mysqli_query($con, $sql);
                    $row = $result -> fetch_array(MYSQLI_NUM);
                    while($row = mysqli_fetch_all($result, MYSQLI_NUM)) {
                        echo $row[0].nl2br("\n");
                    }
                    mysqli_close($con);
                             
            
                    echo "Logged in" . nl2br("\n");
                    echo '<a href=/myOwnFiles/phpLogin.html>Zurück zum Anmeldeformular</a>';
                }
            }
?>
        ];
    });
    return false;
}
</script>


<form onsubmit="buchSuche ()" method="post">
    <label for="search">Suchbegriff</label>
    <input type="text" name="search" id="search" placeholder="Suchbegriff">

    <button class="btn btn-primary" type="submit">Suchen</button>
</form>