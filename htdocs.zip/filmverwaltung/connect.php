<?php
include 'filmsuche.html';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "filmverwaltung";


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
$produktionsfirma_ID = $_POST['search'];

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";


$query = "SELECT `produktionsfirma_ID` FROM `filme` WHERE True";

$result = mysqli_query($conn, $query);
while ($produktionsfirma_ID = mysqli_fetch_all($result, 1)) {
    //echo "Suche nach Produktionsfilm: $produktionsfirma_ID";
}

mysqli_close($conn);


?>

